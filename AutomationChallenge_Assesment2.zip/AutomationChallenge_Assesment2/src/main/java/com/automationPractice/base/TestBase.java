package com.automationPractice.base;

import java.io.File;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class TestBase {
	public static WebDriver driver;
	public static Logger log;

	public TestBase() {
		try {

			PropertyConfigurator.configure(System.getProperty("user.dir")
					+ "\\src\\main\\java\\com\\automationPractice\\config\\log4j.properties");

			log = Logger.getLogger(getClass());
			log.setLevel(Level.DEBUG);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public static void initialization(String browser, String url) {

		switch (browser) {
		case "chrome":
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//src//main//java//com//automationPractice//drivers//chromedriver.exe");
			driver = new ChromeDriver();
			break;

		case "firefox":
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "//src//main//java//com//automationPractice//drivers//geckodriver.exe");
			driver = new FirefoxDriver();
			break;

		default:
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//src//main//java//com//automationPractice//drivers//chromedriver.exe");
			driver = new ChromeDriver();
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.get(url);

	}

	public static void ScreenShot() {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, new File(System.getProperty("user.dir") + "/screenshot.png"));
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
}
