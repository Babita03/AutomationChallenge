package com.automationPractice.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.automationPractice.base.TestBase;

public class OrderPage extends TestBase {
	 WebDriver driver;
	@FindBy(xpath = "(//*[@title='Proceed to checkout'])[2]")
	WebElement proceedbtn;

	@FindBy(xpath = "//ul[@id='address_delivery']/li")
	List<WebElement> deliveryAddressElement;

	@FindBy(xpath = "//ul[@id='address_invoice']/li")
	List<WebElement> billAddressElement;

	@FindBy(name = "processAddress")
	WebElement addressProceedBtn;

	@FindBy(name = "processCarrier")
	WebElement shippingProceedBtn;

	@FindBy(className = "fancybox-error")
	WebElement error;

	@FindBy(css = "#uniform-cgv")
	WebElement serviceTermsCheckBox;

	@FindBy(css = "[title='Close']")
	WebElement closeError;

	public OrderPage( WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void clickOnProceedOrder() {
		proceedbtn.click();

	}

	public String getDeliveryAddress() {
		String Deliver_Address = "";
		int del_elm = deliveryAddressElement.size();
		for (int i = 2; i < del_elm; i++) {
			String address = deliveryAddressElement.get(i).getText();
			Deliver_Address = Deliver_Address + address;
		}
		return Deliver_Address;
	}

	public String getBillingAddress() {
		String Billing_Address = "";
		int invoice_size = billAddressElement.size();
		for (int i = 2; i < invoice_size; i++) {
			String address = billAddressElement.get(i).getText();
			Billing_Address = Billing_Address + address;
		}
		return Billing_Address;

	}

	public void clickOnProceedAddress() {
		addressProceedBtn.click();
	}

	public PaymentPage clickOnProceedShipment() {
		shippingProceedBtn.click();
		return new PaymentPage(driver);
	}

	public String getErrorMsg() {
		return error.getText();
	}

	public void closeError() {
		closeError.click();
	}

	public void checkServiceTerms() {
		serviceTermsCheckBox.click();

	}

}
