package com.automationPractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.automationPractice.base.TestBase;

public class PaymentPage extends TestBase {
	 WebDriver driver;
	@FindBy(className="bankwire")
	WebElement bankWireMethod;
	
	@FindBy(className="page-subheading")
	WebElement Header;
	
	@FindBy(xpath="//span[text()='I confirm my order']")
	WebElement confirmOrderBtn;
	
	public PaymentPage( WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void selectBankWirePaymentMethod() {
		bankWireMethod.click();
	}
	
	public String getheaderMsg() {
		return Header.getText();
	}
	
	public OrderConfirmationPage clickOnConfirmOrder() {
		confirmOrderBtn.click();
		return new OrderConfirmationPage(driver);
	}
}
