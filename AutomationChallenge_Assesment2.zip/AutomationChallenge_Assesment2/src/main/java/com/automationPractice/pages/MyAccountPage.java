package com.automationPractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.automationPractice.base.TestBase;

public class MyAccountPage extends TestBase {
	 WebDriver driver;
	@FindBy(xpath="//*[@id=\"block_top_menu\"]/ul/li[2]/a")
	WebElement dressesMenu;
	
	public MyAccountPage( WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public String getMyAccountPageTitle() {
		return driver.getTitle();
	}
	
	public DressesPage clickOnDresses() {
		dressesMenu.click();
		return new DressesPage(driver);
		
	}
}
