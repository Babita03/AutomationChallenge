package com.automationPractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.automationPractice.base.TestBase;

public class OrderHistoryPage extends TestBase {
	 WebDriver driver;
	@FindBy(css="#order-list > tbody > tr.first_item > td:nth-child(1)")
	WebElement refNo;
	
	@FindBy(css="#order-list > tbody > tr.first_item > td:nth-child(2)")
	WebElement date;
	
	@FindBy(css="#order-list > tbody > tr.first_item > td:nth-child(3)")
	WebElement price;
	
	@FindBy(css="#order-list > tbody > tr.first_item > td:nth-child(4)")
	WebElement paymentMethod;
	
	public OrderHistoryPage( WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public String getOrderRefNo() {
		return refNo.getText();
	}

	public String getOrderDate() {
		return date.getText();
	}
	
	public String getOrderPrice() {
		return price.getText();
	}
	
	public String getOrderPaymentMethod() {
		return paymentMethod.getText();
	}
}

