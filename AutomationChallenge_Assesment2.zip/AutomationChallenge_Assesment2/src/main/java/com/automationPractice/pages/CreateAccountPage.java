package com.automationPractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.automationPractice.base.TestBase;

public class CreateAccountPage extends TestBase {
	 WebDriver driver;
	@FindBy(id="id_gender2")
	WebElement genderTitle;
	
	@FindBy(id="customer_firstname")
	WebElement firstname;
	
	@FindBy(id="customer_lastname")
	WebElement lastName;
	
	@FindBy(id="passwd")
	WebElement passwrd;
	
	@FindBy(id="days")
	WebElement days;
	
	@FindBy(id="months")
	WebElement months;
	
	@FindBy(id="years")
	WebElement years;
	
	@FindBy(id="address1")
	WebElement address;
	
	@FindBy(id="city")
	WebElement city;
	
	@FindBy(id="id_state")
	WebElement state;
	
	@FindBy(id="postcode")
	WebElement pinNo;
	
	@FindBy(id="phone_mobile")
	WebElement mobile;
	
	@FindBy(id="alias")
	WebElement aliasAddress;
	
	@FindBy(id="submitAccount")
	WebElement registerBttn;
	
	public CreateAccountPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void addPersonalInfo() {
		genderTitle.click();
		firstname.sendKeys("Babita");
		lastName.sendKeys("goyal");
		passwrd.sendKeys("babita");
		Select day = new Select(days);
		day.selectByValue("8");
		Select month = new Select(months);
		month.selectByIndex(3);
		Select year = new Select(years);
		year.selectByValue("2020");
	
	}
	
	public void addAddressDetails(String address1, String city1, String state1, String PIN, String mobileno, String Ref) {
		address.sendKeys(address1);
		city.sendKeys(city1);
		state.sendKeys(state1);
		pinNo.sendKeys(PIN);
		mobile.sendKeys(mobileno);
		aliasAddress.sendKeys(Ref);
		
	}
	
	public MyAccountPage ClickOnRegBtn() {
		registerBttn.click();
		return new MyAccountPage(driver);
	}
	
	

}
