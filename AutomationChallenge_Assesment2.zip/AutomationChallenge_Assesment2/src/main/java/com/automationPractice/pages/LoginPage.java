package com.automationPractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.automationPractice.base.TestBase;

public class LoginPage extends TestBase {
	 WebDriver driver;
	@FindBy(className="login")
	WebElement signIn;
	
	@FindBy(id="email_create")
	WebElement createEmail;
	
	@FindBy(id="SubmitCreate")
	WebElement CreateAccountBtn;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnSignIn() {
		signIn.click();
	}
	
	public void setCreateMail(String mail) {
		createEmail.sendKeys(mail);
	}
	
	public CreateAccountPage clickOnCreateAccountBtn() {
		CreateAccountBtn.click();
		return new CreateAccountPage(driver);
	}
}