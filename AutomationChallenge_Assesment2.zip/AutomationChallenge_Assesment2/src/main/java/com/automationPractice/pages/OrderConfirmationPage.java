package com.automationPractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.automationPractice.base.TestBase;

public class OrderConfirmationPage extends TestBase{
	 WebDriver driver;
	@FindBy(xpath="//*[@id='center_column']/div")
	WebElement OrderMsg;
	
	@FindBy(xpath="//*[text()='Back to orders']")
	WebElement backToOrderBtn;
	
	public OrderConfirmationPage( WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public String getOrderMsg() {
		return OrderMsg.getText();
	}
	
	public OrderHistoryPage clickOnBackToOrdr() {
		backToOrderBtn.click();
		return new OrderHistoryPage(driver);
	}
}
