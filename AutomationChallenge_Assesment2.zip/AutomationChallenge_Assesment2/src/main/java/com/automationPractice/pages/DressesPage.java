package com.automationPractice.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.automationPractice.base.TestBase;

public class DressesPage extends TestBase {
  WebDriver driver;
	@FindBy(css="#center_column > ul > li > div > div.left-block > div > a.product_img_link > img")
	WebElement product;
	
	@FindBy(xpath="//*[text()='Add to cart']")
	WebElement AddtoCartBtn;
	
	@FindBy(xpath="//*[@id='center_column']/ul/li[1]/div/div[1]/div/div[2]/span")
	WebElement priceTag;
	
	@FindBy(xpath="//*[@title='Proceed to checkout']")
	WebElement proceedBtn;
	
	
	public DressesPage( WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void moveToProduct() {
		Actions action = new Actions(driver);
        action.moveToElement(product).build().perform();
	}
	
	public boolean isaddToCartDisplayed() {
		return AddtoCartBtn.isDisplayed();
		
	}
	
	public boolean isPriceTagDisplayed() {
		return priceTag.isDisplayed();
		
	}
	
	public void clickonAddToCart() {
		AddtoCartBtn.click();
	}
	
	public boolean verifyPopUpText() {
		return proceedBtn.isDisplayed();
	}

	public OrderPage clickedToproceedOrder() {
		proceedBtn.click();
		return new OrderPage(driver);
	}
	
	
}
