package com.automationPractice.testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.automationPractice.base.TestBase;
import com.automationPractice.pages.OrderConfirmationPage;
import com.automationPractice.pages.OrderHistoryPage;

public class OrderConfirmationPageTest extends TestBase{
 
	OrderConfirmationPage orderConfirmPage;
	OrderHistoryPage orderHis;
	public static String orderMsg;
	
	public OrderConfirmationPageTest() {
		super();
	}
	
	@BeforeClass
	public void setUp() {
		orderConfirmPage=new OrderConfirmationPage(driver);
		log.info("****OrderConfirmationPageTest Starts******");
	}
	
	@Test(priority=0)
	public void getOrderFullMsg() {
	orderMsg=orderConfirmPage.getOrderMsg();
	log.info("*****order message********:"+orderMsg);
	}
	@Test(priority=1)
	public void ClickOnBackToOrders() {
		orderHis=orderConfirmPage.clickOnBackToOrdr();
		log.info("****clicked back to orders******");
		
	}
	
	
}
