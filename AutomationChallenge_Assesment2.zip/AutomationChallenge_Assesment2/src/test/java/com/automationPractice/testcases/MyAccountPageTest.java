package com.automationPractice.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.automationPractice.base.TestBase;
import com.automationPractice.pages.DressesPage;
import com.automationPractice.pages.MyAccountPage;

public class MyAccountPageTest extends TestBase {
	MyAccountPage myAccPage;
	DressesPage dressPage;
	
	public MyAccountPageTest() {
		super();
	}
	
	@BeforeClass
	public void setUp() {
		log.info("*******accountPageTest********");
		myAccPage=new MyAccountPage(driver);
	}
	
	
	@Test(priority=0)
	public void validatePageTitle() {
		String title =myAccPage.getMyAccountPageTitle();
		Assert.assertEquals(title, "My account - My Store");
		log.info("Page title is:" +title);
	}
	
	@Test(priority=1)
	public void clickedDresses() {
		dressPage=	myAccPage.clickOnDresses();
		log.info("******clicked on dresses from menu bar*******");
		
	}
	
}
