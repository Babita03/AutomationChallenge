package com.automationPractice.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.automationPractice.base.TestBase;
import com.automationPractice.pages.OrderPage;
import com.automationPractice.pages.PaymentPage;

public class OrderPageTest extends TestBase {
	OrderPage orderPage;
	PaymentPage paymentPage;

	public OrderPageTest() {
		super();
	}

	@BeforeClass
	public void setUp() {
		orderPage = new OrderPage(driver);
		log.info("******OrderPageTest******");
	}

	@Test(priority = 0)
	public void verifyBillingAndDeliveryAddressSame() {
		orderPage.clickOnProceedOrder();
		log.info("*****clicked on proceedbtn****");
		String deliveryAddress = orderPage.getDeliveryAddress();
		log.info("********delivery adreess****:" + deliveryAddress);
		String billingAddress = orderPage.getBillingAddress();
		log.info("*********Billing Addresss*****:" + billingAddress);
		Assert.assertEquals(deliveryAddress, billingAddress);
		log.info("*****both addresses are Same***");
		orderPage.clickOnProceedAddress();
		log.info("****clicked proceed btn*****");

	}

	@Test(priority = 1)
	public void verifyErrorMsg() {
		orderPage.clickOnProceedShipment();
		String errorMsg = orderPage.getErrorMsg();
		log.info("*****error message***:" + errorMsg);
		Assert.assertEquals(errorMsg, "You must agree to the terms of service before continuing.");
		orderPage.closeError();

	}

	@Test(priority = 3)
	public void checkServiceTermsAndProceed() {
		orderPage.checkServiceTerms();
		paymentPage = orderPage.clickOnProceedShipment();
		log.info("****clicked on shipment proceed buttom***");
	}
}
