package com.automationPractice.testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.automationPractice.base.TestBase;
import com.automationPractice.pages.CreateAccountPage;
import com.automationPractice.pages.LoginPage;

public class LoginPageTest extends TestBase{
	
	LoginPage loginPage;
	CreateAccountPage createAccPage;

	public LoginPageTest() {
		super();
	}

	@Parameters({ "browser", "url" })
	@BeforeSuite
	public void setUp(String browser, String url) {
		initialization(browser, url);
		log.info("********initialization done********");
		loginPage = new LoginPage(driver);

	}

	@Test
	void loginTest() {
		log.info("*****loginPage*********");
		loginPage.clickOnSignIn();
		loginPage.setCreateMail("bab92@gmail.com");
		createAccPage = loginPage.clickOnCreateAccountBtn();
		log.info("***** clicked on createAccount button*****");
	}

	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
}
