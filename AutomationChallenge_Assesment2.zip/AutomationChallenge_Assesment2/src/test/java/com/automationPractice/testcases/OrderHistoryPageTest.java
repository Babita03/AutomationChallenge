package com.automationPractice.testcases;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.automationPractice.base.TestBase;
import com.automationPractice.pages.OrderConfirmationPage;
import com.automationPractice.pages.OrderHistoryPage;

public class OrderHistoryPageTest extends TestBase {
	OrderHistoryPage orderHisPage;
	OrderConfirmationPage orderconfirmpage;

	public OrderHistoryPageTest() {
		super();
	}

	@BeforeClass
	public void setUp() {
		orderHisPage = new OrderHistoryPage(driver);
		orderconfirmpage = new OrderConfirmationPage(driver);
		log.info("******OrderHistoryTest starts*****");
	}

	@Test(priority = 0)
	public void verifyOrderReference() {
		String orderRef = orderHisPage.getOrderRefNo();
		log.info("*****orderRef*****:" + orderRef);

		log.info("*****order message*******:" + orderRef);
		Assert.assertTrue((OrderConfirmationPageTest.orderMsg).contains(orderRef));

	}

	@Test(priority = 1)
	public void verifyOrderDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String date = dtf.format(LocalDate.now()).toString();
		String orderDate = orderHisPage.getOrderDate();
		log.info("****order date****:" + orderDate);
		Assert.assertEquals(orderDate, date);
	}

	@Test(priority = 2)
	public void verifyPriceAndPaymentMethod() throws InterruptedException {
		String price = orderHisPage.getOrderPrice();

		log.info("*******price*****:" + price);
		Assert.assertTrue(OrderConfirmationPageTest.orderMsg.contains(price));
		Thread.sleep(5000);
//		String paymentMethod = orderHisPage.getOrderPaymentMethod();
//		log.info("*******payment method******:" + paymentMethod);
//		Assert.assertEquals(paymentMethod, "Bank wire");
//		TestBase.ScreenShot();

	}

	@Test(priority=3)
	public void verifyPaymentMethod() {
		String paymentMethod = orderHisPage.getOrderPaymentMethod();
		log.info("*******payment method******:" + paymentMethod);
		Assert.assertEquals(paymentMethod, "Bank wire");
		TestBase.ScreenShot();
	}
}
