package com.automationPractice.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.automationPractice.base.TestBase;
import com.automationPractice.pages.OrderConfirmationPage;
import com.automationPractice.pages.PaymentPage;

public class PaymentPageTest extends TestBase {
	PaymentPage paymentPage;
	OrderConfirmationPage orderConfirmPage;

	public PaymentPageTest() {
		super();
	}
	
	@BeforeClass
	public void setUp() {
		paymentPage=new PaymentPage(driver);
		log.info("******PaymentPageTest starts****");
	}
	
	@Test(priority=0)
	public void verifyPaymentMethod() {
		paymentPage.selectBankWirePaymentMethod();
		String heading=paymentPage.getheaderMsg();
		Assert.assertEquals(heading, "BANK-WIRE PAYMENT.");
		log.info("*********verified payment method*********");
	
	}
	
	@Test(priority=1)
	public void ConfirmOrder() {
		 orderConfirmPage = paymentPage.clickOnConfirmOrder();
		 log.info("***********clicked confirm orders*******");
	}

}
