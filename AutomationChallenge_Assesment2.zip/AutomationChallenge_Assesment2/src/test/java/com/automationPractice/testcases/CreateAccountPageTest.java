package com.automationPractice.testcases;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.automationPractice.base.TestBase;
import com.automationPractice.pages.CreateAccountPage;
import com.automationPractice.pages.MyAccountPage;

public class CreateAccountPageTest extends TestBase {
	CreateAccountPage createAccPage;
	MyAccountPage MyAccPage;
	String path = System.getProperty("user.dir")
			+ "\\src\\main\\java\\com\\automationPractice\\testdata\\AddressData.xlsx";
	Object[][] data;

	public CreateAccountPageTest() {
		super();

	}

	@BeforeClass
	public void setUp() {
		createAccPage = new CreateAccountPage(driver);
	}

	@Test(dataProvider = "Adress")
	void createAcount(String address, String city, String state, String PIN, String mobileno, String Ref) throws InterruptedException {
		// log.info(createAccPage.addPersonalInfo());
		Thread.sleep(3000);
		createAccPage.addPersonalInfo();
		log.info("****personal info added*********");
		createAccPage.addAddressDetails(address, city, state, PIN, mobileno, Ref);
		log.info("*********Address added**************");
		MyAccPage = createAccPage.ClickOnRegBtn();
		log.info("******* click on Register Button******");
	}

	@DataProvider(name = "Adress")
	public Object[][] getAddress() throws IOException {

		XSSFCell cellData;

		FileInputStream fs = new FileInputStream(path);
		XSSFWorkbook book = new XSSFWorkbook(fs);
		XSSFSheet sheet = book.getSheetAt(0);
		XSSFRow row = sheet.getRow(0);

		int noOfRows = sheet.getLastRowNum() - sheet.getFirstRowNum();
		int noOfCols = row.getLastCellNum();
		data = new Object[1][noOfCols];

		for (int i = 1; i <= noOfRows; i++) {
			for (int j = 0; j < noOfCols; j++) {

				cellData = sheet.getRow(i).getCell(j);
				try {
					DataFormatter formatter = new DataFormatter();
					data[i - 1][j] = formatter.formatCellValue(cellData);

				} catch (Exception e) {
					data[i - 1][j] = "";
				}finally {
					book.close();
				}
			}
		}
		System.out.println(data);
		return data;
	}

}
