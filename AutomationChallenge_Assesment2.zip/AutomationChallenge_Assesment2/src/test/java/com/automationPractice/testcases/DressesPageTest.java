package com.automationPractice.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.automationPractice.base.TestBase;
import com.automationPractice.pages.DressesPage;
import com.automationPractice.pages.OrderPage;

public class DressesPageTest extends TestBase {
	DressesPage dressPage;
	OrderPage orderPage;

	public DressesPageTest() {
		super();
	}

	@BeforeClass
	public void setUp() {
		dressPage = new DressesPage(driver);
		log.info("******create DressPageObject*****");
	}

	@Test
	public void OrderDress() throws InterruptedException {
		log.info("*****Order dresss in dressPageTest*******");
		dressPage.moveToProduct();
		log.info("***move to product*****");
		boolean value = dressPage.isaddToCartDisplayed();
		Assert.assertTrue(value);
		log.info("****add to cart is displayed** " + value);
		boolean price = dressPage.isPriceTagDisplayed();
		//Assert.assertTrue(price);
		log.info("****price is displayed** " + price);
		dressPage.clickonAddToCart();
		Thread.sleep(5000);
		boolean flag = dressPage.verifyPopUpText();
		Assert.assertTrue(flag);
		log.info("*******pop up with proceed to checkout*******");
		orderPage = dressPage.clickedToproceedOrder();

	}

}
