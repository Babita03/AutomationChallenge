package automationPractice;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeClass;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Testcases {
	WebDriver driver;
	String path = System.getProperty("user.dir") + "//AddressData.xlsx";
	Object[][] data;
	String Billing_Address = "";
	String Deliver_Address = "";
	String orderMessage = "";

	@Parameters({ "browser", "url" })
	@BeforeClass
	public void setUp(String browser, String url) {
		switch (browser) {
		case "chrome":
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//chromedriver.exe");
			driver = new ChromeDriver();
			break;

		case "firefox":
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "//geckodriver.exe");
			driver = new FirefoxDriver();
			break;

		default:
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//chromedriver.exe");
			driver = new ChromeDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Test(dataProvider = "Adress")
	void TC1(String address, String city, String state, String PIN, String mobileno, String Ref)
			throws InterruptedException {
		driver.findElement(By.className("login")).click();
		driver.findElement(By.id("email_create")).sendKeys("anarya41@gmail.com");
		driver.findElement(By.id("SubmitCreate")).click();
		// Thread.sleep(1000);
		driver.findElement(By.id("id_gender2")).click();
		driver.findElement(By.id("customer_firstname")).sendKeys("Anarya");
		driver.findElement(By.id("customer_lastname")).sendKeys("Sharma");
		driver.findElement(By.id("passwd")).sendKeys("Selenium");
		WebElement days = driver.findElement(By.id("days"));
		Select day = new Select(days);
		day.selectByValue("8");

		WebElement months = driver.findElement(By.id("months"));
		Select month = new Select(months);
		month.selectByIndex(3);

		WebElement years = driver.findElement(By.id("years"));
		Select year = new Select(years);
		year.selectByValue("2020");
		driver.findElement(By.id("address1")).sendKeys(address);
		driver.findElement(By.id("city")).sendKeys(city);
		WebElement States = driver.findElement(By.id("id_state"));
		Select state1 = new Select(States);
		state1.selectByVisibleText(state);
		driver.findElement(By.id("postcode")).sendKeys(PIN);
		driver.findElement(By.id("phone_mobile")).sendKeys(mobileno);
		driver.findElement(By.id("alias")).sendKeys(Ref);
		driver.findElement(By.id("submitAccount")).click();
		Assert.assertEquals(driver.getTitle(), "My account - My Store");
	}

	@Test(priority = 1)
	void TC_02() throws InterruptedException, IOException {
		driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a")).click();
		Actions action = new Actions(driver);
		WebElement product = driver.findElement(
				By.cssSelector("#center_column > ul > li > div > div.left-block > div > a.product_img_link > img"));
		action.moveToElement(product).build().perform();
		product.findElement(By.xpath("//*[text()='Add to cart']")).isDisplayed();
		product.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[1]/div/div[2]/span")).isDisplayed();
		product.findElement(By.xpath("//*[text()='Add to cart']")).click();
		driver.findElement(By.xpath("//*[@title='Proceed to checkout']")).isDisplayed();
		driver.findElement(By.xpath("//*[@title='Proceed to checkout']")).click();
		driver.findElement(By.xpath("(//*[@title='Proceed to checkout'])[2]")).click();
		int size_Delivery_elements = driver.findElements(By.xpath("//ul[@id='address_delivery']/li")).size();
		for (int i = 2; i < size_Delivery_elements; i++) {
			String address = driver.findElement(By.xpath("//ul[@id='address_delivery']/li[" + i + "]")).getText();
			Deliver_Address = Deliver_Address + address;
		}

		int invoice_size = driver.findElements(By.xpath("//ul[@id='address_invoice']/li")).size();
		for (int i = 2; i < invoice_size; i++) {
			String address = driver.findElement(By.xpath("//ul[@id='address_invoice']/li[" + i + "]")).getText();
			Billing_Address = Billing_Address + address;
		}

		Assert.assertEquals(Deliver_Address, Billing_Address);
		driver.findElement(By.cssSelector("[name='processAddress']")).click();
		driver.findElement(By.cssSelector("[name='processCarrier']")).click();
		String error_message = driver.findElement(By.className("fancybox-error")).getText();
		Assert.assertEquals(error_message, "You must agree to the terms of service before continuing.");
		driver.findElement(By.cssSelector("[title='Close']")).click();
		driver.findElement(By.cssSelector("#uniform-cgv")).click();
		driver.findElement(By.cssSelector("[name='processCarrier']")).click();
		driver.findElement(By.className("bankwire")).click();
		String heading = driver.findElement(By.className("page-subheading")).getText();
		System.out.println(heading);
		Assert.assertEquals(heading, "BANK-WIRE PAYMENT.");
		driver.findElement(By.xpath("//span[text()='I confirm my order']")).click();
		orderMessage = driver.findElement(By.cssSelector("#center_column > div.box")).getText();
		System.out.println(orderMessage);
		driver.findElement(By.xpath("//*[text()='Back to orders']")).click();
		String Ref = driver.findElement(By.cssSelector("#order-list > tbody > tr.first_item > td:nth-child(1)"))
				.getText();
		Assert.assertTrue(orderMessage.contains(Ref));
		String actualDate = driver.findElement(By.cssSelector("#order-list > tbody > tr.first_item > td:nth-child(2)"))
				.getText();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String date = dtf.format(LocalDate.now()).toString();
		Assert.assertEquals(actualDate, date);
		String totalPrice = driver.findElement(By.cssSelector("#order-list > tbody > tr.first_item > td:nth-child(3)"))
				.getText();
		Assert.assertTrue(orderMessage.contains(totalPrice));
		String paymentMethod=driver.findElement(By.cssSelector("#order-list > tbody > tr.first_item > td:nth-child(4)"))
		.getText();
		Assert.assertEquals(paymentMethod,"Bank wire");
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File(System.getProperty("user.dir") + "/screenshot.png"));
	}

	@DataProvider(name = "Adress")
	public Object[][] getAddress() throws IOException {

		XSSFCell cellData;

		FileInputStream fs = new FileInputStream(path);
		XSSFWorkbook book = new XSSFWorkbook(fs);
		XSSFSheet sheet = book.getSheetAt(0);
		XSSFRow row = sheet.getRow(0);

		int noOfRows = sheet.getLastRowNum() - sheet.getFirstRowNum();
		int noOfCols = row.getLastCellNum();
		data = new Object[1][noOfCols];

		for (int i = 1; i <= noOfRows; i++) {
			for (int j = 0; j < noOfCols; j++) {

				cellData = sheet.getRow(i).getCell(j);
				try {
					DataFormatter formatter = new DataFormatter();
					data[i - 1][j] = formatter.formatCellValue(cellData);

				} catch (Exception e) {
					data[i - 1][j] = "";
				} finally {
					book.close();
				}
			}
		}
		System.out.println(data);
		return data;
	}

	@AfterClass
	void tearDown() {
		driver.quit();
	}
}
